### En Server 1
### Inicia el clúster Docker Swarm y une a las otras máquinas.
echo "Arrancamos el Docker Swarm el clúster Docker Swarm y añadimos a las otras máquinas ..."
source .env
docker swarm leave -f
docker swarm init
echo "Copia y ejecuta esto en los otros nodos.  Ej : 'docker swarm join {token...............}  ' "
sleep 10
docker node promote $ORG1_HOSTNAME
docker node promote $ORG2_HOSTNAME
docker node ls
