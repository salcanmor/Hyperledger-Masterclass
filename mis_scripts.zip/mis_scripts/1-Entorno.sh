### En Server 1
### Copiamos los archivos de configuración de docker 
cd ~/fabric-samples
mkdir BSM
cd BSM
cp ../first-network/configtx.yaml .
cp ../first-network/crypto-config.yaml .
cp ../mis_scripts/.env .
cp ../mis_scripts/* .
cp -r ../mis_scripts/org1 .
cp -r ../mis_scripts/org2 .
ls -altr
cd ~/fabric-samples/BSM


