### ON Server 2

cd ~/fabric-samples/hlfnet
source .env
echo "Comprobando el nombre del CLI"   
echo $CLI_NAME
echo "Creando el canal"
docker exec "$CLI_NAME" peer channel create -o "$ORDERER_NAME":7050 -c "$CHANNEL_NAME" -f "$CHANNEL_TX_LOCATION" --tls --cafile $ORDERER_CA
sleep 1
echo "Añadiendo la Org1 al canal ..."
docker exec "$CLI_NAME" peer channel join -b "$CHANNEL_NAME".block --tls --cafile $ORDERER_CA
sleep 1
echo "Añadiendo la Org2 al canal ..."
docker exec -e "CORE_PEER_LOCALMSPID=Org2MSP" -e "CORE_PEER_TLS_CERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org2.example.com/tls/server.crt" -e "CORE_PEER_TLS_KEY_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/server.key" -e "CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp" -e "CORE_PEER_ADDRESS=peer0.org2.example.com:7051" "$CLI_NAME" peer channel join -b "$CHANNEL_NAME".block --tls --cafile $ORDERER_CA
sleep 1 
echo "Org1 - Instalando el chaincode Fabcar ..."
docker exec "$CLI_NAME" peer chaincode install -n "$CC_NAME" -p "$CC_SRC" -v "$CC_VERSION" -l "$CC_RUNTIME_LANGUAGE"
sleep 2
echo "Actualizando Anchor Peer para Org1..."
docker exec "$CLI_NAME" peer channel update  -o "$ORDERER_NAME":7050 -c "$CHANNEL_NAME" -f "$ORG1_ANCHOR_TX" --tls --cafile $ORDERER_CA
echo "Actualizando Anchor Peer para Org2.."
docker exec -e "CORE_PEER_LOCALMSPID=Org2MSP" -e "CORE_PEER_TLS_CERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.example.com/peers/peer0.org2.example.com/tls/server.crt" -e "CORE_PEER_TLS_KEY_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/server.key" -e "CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp" -e "CORE_PEER_ADDRESS=peer0.org2.example.com:7051" "$CLI_NAME" peer channel update  -o "$ORDERER_NAME":7050 -c "$CHANNEL_NAME" -f "$ORG2_ANCHOR_TX" --tls --cafile $ORDERER_CA

echo "Org2 - Instalando el chaincode Fabcar ..."
docker exec -e CORE_PEER_LOCALMSPID=Org2MSP -e CORE_PEER_ADDRESS=peer0.org2.example.com:7051 -e CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp -e CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt "$CLI_NAME" peer chaincode install -n "$CC_NAME" -v "$CC_VERSION" -p "$CC_SRC" -l "$CC_RUNTIME_LANGUAGE"
sleep 5
echo "Instanciando el chaincode Fabcar ..."
docker exec   -e CORE_PEER_LOCALMSPID=Org1MSP   -e CORE_PEER_MSPCONFIGPATH=${ORG1_MSPCONFIGPATH}   "$CLI_NAME"   peer chaincode instantiate     -o orderer.example.com:7050     -C mychannel     -n "$CC_NAME"     -l "$CC_RUNTIME_LANGUAGE"     -v "$CC_VERSION"     -c '{"Args":[]}'     -P "AND('Org1MSP.member','Org2MSP.member')"     --tls     --cafile ${ORDERER_TLS_ROOTCERT_FILE}     --peerAddresses peer0.org1.example.com:7051     --tlsRootCertFiles ${ORG1_TLS_ROOTCERT_FILE}
sleep 15
echo "Haciendo una query al Chaincode Fabcar ..."
echo "Esto llevará algún tiempo ..... "
docker exec   -e CORE_PEER_LOCALMSPID=Org1MSP   -e CORE_PEER_MSPCONFIGPATH=${ORG1_MSPCONFIGPATH}   "$CLI_NAME"   peer chaincode invoke     -o orderer.example.com:7050     -C mychannel     -n fabcar     -c '{"function":"initLedger","Args":[]}'     --waitForEvent     --tls     --cafile ${ORDERER_TLS_ROOTCERT_FILE}     --peerAddresses peer0.org1.example.com:7051     --peerAddresses peer0.org2.example.com:7051     --tlsRootCertFiles ${ORG1_TLS_ROOTCERT_FILE}     --tlsRootCertFiles ${ORG2_TLS_ROOTCERT_FILE}
