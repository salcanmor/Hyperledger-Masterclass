##### En Server 1
source .env
echo
echo "##### Recuerda, tienes que actualizar las crypto keys en org1/docker-composer-services.yml & org2/docker-composer-services.yml "
echo "##### para los servicios de la CA, de otro modo los contenedores fallarán, si no lo has hecho presiona 'Ctrl+c' aquí   "
echo 
echo 
sleep 10
echo "Creando la red para añadir los nodos docker"
docker network create --attachable --driver overlay fabcar_net
echo
##### En Server 1 o en cualquier otro, pero se debe mantener esta secuencia
echo "Arrancando el nodo Orderer ..."
docker stack deploy -c "$ORDERER0_COMPOSE_PATH" hlf_orderer
sleep 5
echo "Arrancando los servicios de la Org1 ..."
docker stack deploy -c "$SERVICE_ORG1_COMPOSE_PATH" hlf_services
sleep 5
echo "Arrancando los peer nodes de la Org1 ..."
docker stack deploy -c "$PEER_ORG1_COMPOSE_PATH" hlf_peer
sleep 3
echo "Arrancando los servicios de la Org2 ..."
docker stack deploy -c "$SERVICE_ORG2_COMPOSE_PATH" hlf_services
sleep 5
echo "Arrancando los peer nodes de la Org2 ..."
docker stack deploy -c "$PEER_ORG2_COMPOSE_PATH" hlf_peer
sleep 5

docker service ls

echo " Loguéate en la máquina $ORG1_HOSTNAME y ejecuta el script de creación de los canales"
